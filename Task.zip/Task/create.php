<?php

require_once 'app/init.php';



    
    if (isset($_POST['submit'])) {
        $formAnswers = array();

        foreach ($_POST as $key => $value) {
            if ($key != "submit") {
                $formAnswers[] = $value;
            }
        }

        // echo '<pre>', print_r($formAnswers), '</pre>';

    //check if any of the fields are empty
        if (in_array("", $formAnswers)) {
            echo '<script>alert("Please fill out all fields")</script>';
        } else {
           
            $stmt = $db->prepare("
                INSERT INTO polls (question, starts, ends)
                SELECT :question , :starts, :ends
                
            ");
            $stmt->execute([
                'question' => $formAnswers[2],
                'starts' => $formAnswers[0],
                'ends' => $formAnswers[1]
            ]);

            $stmt = $db->prepare("SELECT MAX(id) FROM polls");
            $stmt->execute();
            $maxId = $stmt->fetch();
            // echo '<pre>', print_r($maxId, true), '</pre>';

            $nextId = $maxId[0];
            $nextName = $formAnswers[3];
            // $stmt = $db->prepare("
            //         INSERT INTO polls_choices (poll, name) 
            //         SELECT :poll, :name
            //     ");
            
            //     $stmt->execute([
            //         'poll' => $maxId[0],
            //         'name' => $formAnswers[3]
            //     ]);

            for ($elem = 3; $elem < count($formAnswers); $elem++) {
                
                $stmt = $db->prepare("
                    INSERT INTO polls_choices (poll, name) VALUES (:poll, :name)
                ");
                $stmt->execute([
                    'poll' => $maxId[0],
                    'name' => $formAnswers[$elem]
                ]);
            }

            // $stmt = $db->prepare("INSERT INTO polls () VALUES (?)");
            header('Location: index.php');
        }


}

    


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="css/style.css">
    <title>Poll Creation</title>



</head>

<body>
    <h1>Create a Poll</h1>
    

    <form id="form" method="post">

        <label for="start_date">Start Date:</label><br>
        <input type="date" id="start_date" name="start_date"><br>
        <label for="exp_date">Expiry Date:</label><br>
        <input type="date" id="exp_date" name="exp_date"><br>
        
        <br> Question: <input type="text" name="question" id="question"></br>
        <br>Choice 1: <input type="text" name="c1" id="c1"></br>
        <br>Choice 2: <input type="text" name="c2" id="c2"></br>

        
        <br><button type="button" onclick="addInputField()" style="font-weight: bold; width: 150px; height: 75px; background-color: #CFB3CD; border-radius: 10px;">Add a choice</button></br>
        
        
    </form>
    <div id="submitcreate">
        <br><button type="submit" form="form" value="Submit" name="submit" style="font-weight: bold; width: 150px; height: 75px; background-color: #CFB3CD; border-radius: 10px;">Submit</button></br>
    </div>
    <div id="back">
        <br><button type="button" onclick="window.location.href='index.php'" style="font-weight: bold; width: 150px; height: 75px; background-color: #CFB3CD; border-radius: 10px;">Back</button></br>
    </div>
    


    <script>


        function addInputField() {
            var numInputs = document.getElementsByTagName('input').length;
            if (numInputs >= 13) {
                alert("You have reached the maximum number of input fields (10).");
                return;
            }
            var input = '<p>Choice ' + (numInputs - 2) + ': <input type="text"' + 'name="' + 'c' + (numInputs - 2) + '"' + 'id="' + 'c' + (numInputs - 2)+ '"></p>';

            document.getElementById("form").innerHTML += input;
        }

       

    </script>


</body>

</html>

