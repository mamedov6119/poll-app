<?php 

require_once 'app/init.php';

if (isset($_POST['poll'], $_POST['choice'])) {
    $poll = $_POST['poll'];
    $choice = $_POST['choice'];



    $voteQuery = $db->prepare("
        INSERT INTO polls_answers (user, poll, choice)
            SELECT :user, :poll, :choice
            FROM polls
            WHERE EXISTS (
                SELECT id
                FROM polls
                WHERE id = :poll
                AND DATE(NOW()) BETWEEN starts AND ends
            )
            AND EXISTS (
                SELECT id
                FROM polls_choices  
                WHERE id = :choice
                AND poll = :poll
            )
            AND NOT EXISTS (
                SELECT id
                FROM polls_answers
                WHERE user = :user
                AND poll = :poll
            )
            
            LIMIT 1
    ");

    $voteQuery->execute([
        'user' => $_SESSION['user_id'],
        'poll' => $poll,
        'choice' => $choice
    ]);
    
    header('Location: poll.php?poll=' . $poll);

}

if(!empty($choice)) {
    header("Location:thankyou.php");
} else {
    
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" 
     type="image/jpg" 
     <?php 
        $icons = array("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-cWLx8TGFpgWxsJsuedlHBGabGSgdYMaIig&usqp=CAU","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZy-JvmFg4UkhpwbpQqZO0XdyRmwVYtw1Abg&usqp=CAU","https://carbunkletrumpet.files.wordpress.com/2018/03/random-pictures-that-make-no-sense-18-1.jpg", "https://thechive.com/wp-content/uploads/2019/12/person-hilariously-photoshops-animals-onto-random-things-xx-photos-8.jpg?attachment_cache_bust=3136470&quality=85&strip=info&w=400", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfMgz69Vu2ADKI0ywdKy9NDvp8hhpwZg6gZA&usqp=CAU", "https://img-9gag-fun.9cache.com/photo/a3Q5VW5_460s.jpg", "https://i.pinimg.com/originals/ec/ac/24/ecac244e7641c464ff7ad117217164d0.jpg");
        shuffle($icons);
        echo "href=" . current($icons);
     ?>>
     <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <h1 id="optionnotselected" style="">Please, select an option!</h1>
    <?php 
    echo "<script>";
    echo "setTimeout(function(){ window.location.href = 'index.php'; }, 4000);";
    echo "</script>";
    ?>
</body>
</html>