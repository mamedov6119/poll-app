<?php

require_once 'app/init.php';

if (!isset($_GET['poll'])) {
    header('Location: index.php');
} else {
    $id = (int)$_GET['poll'];

    $pollQuery = $db->prepare("
        SELECT id, question
        FROM polls
        WHERE id = :poll
        AND DATE(NOW()) BETWEEN starts AND ends
    ");

    $pollQuery->execute([
        'poll' => $id
    ]);

    $poll = $pollQuery->fetchObject();

    $choicesQuery = $db->prepare("
        SELECT polls.id, polls_choices.id AS choice_id, polls_choices.name
        FROM polls
        JOIN polls_choices
        ON polls.id = polls_choices.poll
        WHERE polls.id = :poll
        AND DATE(NOW()) BETWEEN polls.starts AND polls.ends
    ");

    $choicesQuery->execute([
        'poll' => $id
    ]);

    while ($row = $choicesQuery->fetchObject()) {
        $choices[] = $row;
    }
    
    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" 
     type="image/jpg" 
     <?php 
        $icons = array("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-cWLx8TGFpgWxsJsuedlHBGabGSgdYMaIig&usqp=CAU","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZy-JvmFg4UkhpwbpQqZO0XdyRmwVYtw1Abg&usqp=CAU","https://carbunkletrumpet.files.wordpress.com/2018/03/random-pictures-that-make-no-sense-18-1.jpg", "https://thechive.com/wp-content/uploads/2019/12/person-hilariously-photoshops-animals-onto-random-things-xx-photos-8.jpg?attachment_cache_bust=3136470&quality=85&strip=info&w=400", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfMgz69Vu2ADKI0ywdKy9NDvp8hhpwZg6gZA&usqp=CAU", "https://img-9gag-fun.9cache.com/photo/a3Q5VW5_460s.jpg", "https://i.pinimg.com/originals/ec/ac/24/ecac244e7641c464ff7ad117217164d0.jpg");
        shuffle($icons);
        echo "href=" . current($icons);
     ?>>
    <title>Document</title>

</head>
    <body>
        <?php if(!$poll): ?>
            <div class="notavailable"><p>The poll is not available.</p></div>
            <img src="<?php shuffle($icons); echo $icons[0]?>" alt="Something went wrong." style="width: 300px; height: 300px;" class="center">
            
        <?php else: ?>
            <div class="poll">
                <div class="poll-question">
                    <?php echo $poll->question; ?>
                </div>
                
                    <?php if(!empty($choices)): ?>
                        <form action="vote.php" method="post">
                            
                            <div class="poll-options">

                                <?php foreach($choices as $index => $choice): ?>
                                    <div class="poll-option">
                                        <input type="radio" name="choice" value="<?php echo $choice->choice_id; ?>" id="ch<?php echo $index; ?>">
                                        <label for="ch<?php echo $index ?>"><?php echo $choice->name ?></label><br>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="submitanswer">
                            <input type="submit" value="Submit Answer" style="font-weight: bold; width: 150px; height: 75px; background-color: #CFB3CD; border-radius: 10px;">
                             </div>       
                            <input type="hidden" name="poll" value="<?php echo $id; ?>" >
                        </form>
                    <?php else: ?>
                        <div class="nochoices"><p>There are no choices for this poll.</p></div> 
                        <img src="<?php shuffle($icons); echo $icons[0]?>" alt="Something went wrong." style="width: 300px; height: 300px;" class="center">

                    <?php endif; ?>
            </div>
        <?php endif; ?>

        <div id="back">
     

            <br><button type="button" onclick="window.location.href='index.php'" style="font-weight: bold; width: 150px; height: 75px; background-color: #CFB3CD; border-radius: 10px;">Back</button></br>
          
        </div>

    </body>
</html>