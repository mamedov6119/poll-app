<?php

session_start();

$_SESSION['user_id'] = 1;

$servername = "sql11.freesqldatabase.com";
$username = "sql11589995";
$databasename = "sql11589995";
$password = "XgwB1C1WYD";

// try {
    $db = new PDO("mysql:host=$servername;dbname=$databasename", $username, $password);
    
//     echo "Connected successfully";

// } catch (PDOException $e) {
//     echo "Connection failed: " . $e->getMessage();
// }





?>
