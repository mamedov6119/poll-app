<?php


require_once 'app/init.php';


$pollsQuery = $db->query("
    SELECT id, question, date_format(starts, '%M %d, %Y') AS starts, date_format(ends, '%M %d, %Y') AS ends
    FROM polls
    WHERE DATE(NOW()) BETWEEN starts AND ends
    ORDER BY starts DESC
    
");

$pollsQueryEXPIRED = $db->query("
    SELECT id, question, date_format(starts, '%M %d, %Y') AS starts, date_format(ends, '%M %d, %Y') AS ends
    FROM polls
    WHERE DATE(NOW()) > ends
    ORDER BY ends DESC
");



while ($row = $pollsQuery->fetchObject()) {
    $polls[] = $row;
}

while ($row = $pollsQueryEXPIRED->fetchObject()) {
    $pollsEXPIRED[] = $row;
}





?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="icon" href="">
    <link rel="icon" 
     type="image/jpg" 
     <?php 
        $icons = array("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-cWLx8TGFpgWxsJsuedlHBGabGSgdYMaIig&usqp=CAU","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZy-JvmFg4UkhpwbpQqZO0XdyRmwVYtw1Abg&usqp=CAU","https://carbunkletrumpet.files.wordpress.com/2018/03/random-pictures-that-make-no-sense-18-1.jpg", "https://thechive.com/wp-content/uploads/2019/12/person-hilariously-photoshops-animals-onto-random-things-xx-photos-8.jpg?attachment_cache_bust=3136470&quality=85&strip=info&w=400", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfMgz69Vu2ADKI0ywdKy9NDvp8hhpwZg6gZA&usqp=CAU", "https://img-9gag-fun.9cache.com/photo/a3Q5VW5_460s.jpg", "https://i.pinimg.com/originals/ec/ac/24/ecac244e7641c464ff7ad117217164d0.jpg");
        shuffle($icons);
        echo "href=" . current($icons);
     ?>>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <p style="text-align: center; font-size: 100px; text-decoration: overline underline; margin-top: 20px;">Current polls!</p>
    <?php  if (!empty($polls)):  ?>
        <ul>
            <?php  foreach ($polls as $poll):  ?>
                <div class="card" style="background-color: #CCDDF5 ;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $poll->question . " #" . $poll->id?></h5>
                    <p class="card-text" >Click on the vote button to answer the poll! 
                    <?php echo "Date: " . $poll->starts . " - " . $poll->ends  ; ?>
                    </p>
                    <a href="poll.php?poll=<?php echo $poll->id; ?>" class="btn btn-primary" style="background-color:#8D8FA5; border-color: #8D8FA5;">Vote</a>
                </div>
            </div>
              
            <?php  endforeach;  ?>
        </ul>
    <?php  else:  ?>
        <p>Sorry, no polls are available at the moment.</p>
        
    <?php  endif;  ?> 
    </div>
  
        
    <p style="text-align: center; font-size: 100px; text-decoration: overline underline;">Expired polls!</p>

    <?php  if (!empty($pollsEXPIRED)):  ?>
        <ul>
            <?php  foreach ($pollsEXPIRED as $poll):  ?>
                <div class="card" style="background-color: #CCDDF5 ;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $poll->question . " #" . $poll->id?></h5>
                    <p class="card-text" >Click on the vote button to answer the poll! 
                    <?php echo "Date: " . $poll->starts . " - " . $poll->ends  ; ?>
                    </p>
                    <a href="poll.php?poll=<?php echo $poll->id; ?>" class="btn btn-primary" style="background-color:#8D8FA5; border-color: #8D8FA5;">Vote</a>
                </div>
            </div>
              
            <?php  endforeach;  ?>
        </ul>
    <?php  else:  ?>
        <p>Sorry, no polls are available at the moment.</p>
    <?php  endif;  ?>
    
    <div class="create">
        <a href="create.php"><input style="background-color: #CFB3CD; color: black; width: 150px; height: 50px; font-weight: bold; font-size: 20px; border-radius: 10px; ;" type="button" class="btn btn-primary" value="Create a poll" ></a> </a>
    </div>

</body>
</html>
