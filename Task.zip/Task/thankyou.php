


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" 
     type="image/jpg" 
     <?php 
        $icons = array("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-cWLx8TGFpgWxsJsuedlHBGabGSgdYMaIig&usqp=CAU","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZy-JvmFg4UkhpwbpQqZO0XdyRmwVYtw1Abg&usqp=CAU","https://carbunkletrumpet.files.wordpress.com/2018/03/random-pictures-that-make-no-sense-18-1.jpg", "https://thechive.com/wp-content/uploads/2019/12/person-hilariously-photoshops-animals-onto-random-things-xx-photos-8.jpg?attachment_cache_bust=3136470&quality=85&strip=info&w=400", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfMgz69Vu2ADKI0ywdKy9NDvp8hhpwZg6gZA&usqp=CAU", "https://img-9gag-fun.9cache.com/photo/a3Q5VW5_460s.jpg", "https://i.pinimg.com/originals/ec/ac/24/ecac244e7641c464ff7ad117217164d0.jpg");
        shuffle($icons);
        echo "href=" . current($icons);
     ?>>
     <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <h1>Thank you for your vote!</h1>
    <img src="<?php shuffle($icons); echo $icons[0]?>" alt="Something went wrong." style="width: 300px; height: 300px; margin-top: 100px;" class="center">
    <?php 
    echo "<script>";
    echo "setTimeout(function(){ window.location.href = 'index.php'; }, 4000);";
    echo "</script>";
    ?>
</body>
</html>
